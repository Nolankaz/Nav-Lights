G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.4*
G04 #@! TF.CreationDate,2026-01-20T16:59:12-08:00*
G04 #@! TF.ProjectId,Nav-Lights,4e61762d-4c69-4676-9874-732e6b696361,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.4) date 2026-01-20 16:59:12*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
%AMOutline5P*
0 Free polygon, 5 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 5*
0 $1 to $10 corner X, Y*
0 $11 Rotation angle, in degrees counterclockwise*
0 create outline with 5 corners*
4,1,5,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$1,$2,$11*%
%AMOutline6P*
0 Free polygon, 6 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 6*
0 $1 to $12 corner X, Y*
0 $13 Rotation angle, in degrees counterclockwise*
0 create outline with 6 corners*
4,1,6,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$1,$2,$13*%
%AMOutline7P*
0 Free polygon, 7 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 7*
0 $1 to $14 corner X, Y*
0 $15 Rotation angle, in degrees counterclockwise*
0 create outline with 7 corners*
4,1,7,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$1,$2,$15*%
%AMOutline8P*
0 Free polygon, 8 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 8*
0 $1 to $16 corner X, Y*
0 $17 Rotation angle, in degrees counterclockwise*
0 create outline with 8 corners*
4,1,8,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$1,$2,$17*%
G04 Aperture macros list end*
%ADD10RoundRect,0.760000X-1.140000X-1.140000X1.140000X-1.140000X1.140000X1.140000X-1.140000X1.140000X0*%
%ADD11C,3.800000*%
%ADD12R,0.600000X1.500000*%
%ADD13Outline5P,-0.300000X0.630000X-0.180000X0.750000X0.300000X0.750000X0.300000X-0.750000X-0.300000X-0.750000X0.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J1*
X130900000Y-96200000D03*
D11*
X135900000Y-96200000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,D1*
X152200000Y-95800000D03*
D13*
X153100000Y-95800000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,D3*
X148900000Y-93100000D03*
D13*
X149800000Y-93100000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,D4*
X148900000Y-95800000D03*
D13*
X149800000Y-95800000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,D2*
X152200000Y-93100000D03*
D13*
X153100000Y-93100000D03*
G04 #@! TD*
M02*
